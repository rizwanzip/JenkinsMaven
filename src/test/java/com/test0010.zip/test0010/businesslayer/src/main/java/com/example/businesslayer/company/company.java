package com.example.businesslayer.company;

public class company {

    public String getCompanyNam(){

    return "ABC Company";

        }


}
