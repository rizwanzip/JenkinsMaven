package com.example.businesslayer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BusinesslayerApplication {

	public static void main(String[] args) {
		SpringApplication.run(BusinesslayerApplication.class, args);
	}

}
