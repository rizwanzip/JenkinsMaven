package com.example.businesslayer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BusinesslayerApplicationTests {

	@Test
	void contextLoads() {
	}

}
