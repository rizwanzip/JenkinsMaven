package com.example.test0010;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Test0010ApplicationTests {

	@Test
	void contextLoads() {
	}

}
