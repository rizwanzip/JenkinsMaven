package com.example.test0010;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
//import com.centegy.core.web.controllers.rest.RestControllerBase;
import com.example.business

@SpringBootApplication
public class Test0010Application {

	public com.example.businesslayer.company com= com.example.businesslayer.company;
	public static void main(String[] args) {

		SpringApplication.run(Test0010Application.class, args);


	}

}
