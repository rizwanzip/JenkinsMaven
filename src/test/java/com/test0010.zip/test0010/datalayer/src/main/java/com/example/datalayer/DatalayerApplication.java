package com.example.datalayer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DatalayerApplication {

	public static void main(String[] args) {
		SpringApplication.run(DatalayerApplication.class, args);
	}

}
