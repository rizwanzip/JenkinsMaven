package  com.demo.goov;

class GroovUtils {
	static File initDir(String dir) {
		String outputrep = dir;

		File outputDir = new File(outputrep);

		if (outputDir.exists()) {
//            		outputDir.delete();
//			outputDir.mkdirs();
		}
		else {
			outputDir.mkdirs();
		}
		return outputDir;
	}
	static File initFile(String file) {
		return new File(file);
	}
}
