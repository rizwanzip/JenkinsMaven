package com.demo.goov

import org.gradle.api.DefaultTask
import org.gradle.api.file.Directory
import org.gradle.api.file.DirectoryProperty
import org.gradle.api.file.FileCollection
import org.gradle.api.provider.Property
import org.gradle.api.tasks.Input
import org.gradle.api.tasks.InputDirectory
import org.gradle.api.tasks.OutputDirectory
import org.gradle.api.tasks.PathSensitive
import org.gradle.api.tasks.PathSensitivity
import org.gradle.api.tasks.TaskAction
import org.gradle.api.tasks.incremental.IncrementalTaskInputs
import org.gradle.internal.file.FileType
import org.gradle.internal.impldep.org.apache.commons.io.FilenameUtils

import java.nio.charset.StandardCharsets
import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.Paths
import java.nio.file.StandardCopyOption
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.stream.Stream

class ManageNewDependencyTask extends DefaultTask {
	@InputDirectory
	def FileCollection sourceFiles

	@OutputDirectory
	def File publishDir
	
	def outputBinDir;
	
	@TaskAction
	void execute(IncrementalTaskInputs inputs) {
		println "ManageNewDependencyTask ---> $publishDir || $sourceFiles"
		
		println inputs.incremental ? "CHANGED inputs considered out of date"
		: "ALL inputs considered out of date"

		outputBinDir = GroovUtils.initFile(Paths.get(publishDir.path, project.version, "WEB-INF", "lib").toString());

//		if(inputs.incremental) {
			inputs.outOfDate { change ->
				
				if (change.file.isFile()) {
					println("Assembling dependency -> " + change.file.toPath() + ":" + outputBinDir.path);
			
					project.copy {
						from change.file
						into "file://$outputBinDir.path"
					}
				}
			}
		//}
	}
}
