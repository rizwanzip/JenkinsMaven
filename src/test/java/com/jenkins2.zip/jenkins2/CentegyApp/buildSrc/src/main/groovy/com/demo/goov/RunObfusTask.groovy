package com.demo.goov

import org.gradle.api.DefaultTask
import org.gradle.api.tasks.TaskAction
import org.gradle.api.tasks.Input

import java.nio.file.Paths

import java.io.*;

class RunObfusTask extends DefaultTask {

    @Input
    def File publishDir
	
	def outputDir;

    @TaskAction
    void execute() {
		outputDir = GroovUtils.initFile(Paths.get(publishDir.path, project.version).toString());

        if (outputDir.exists()) {
            Process pro = Runtime.getRuntime().exec("..\\obfus\\RunAllatori.bat")
			
			pro.waitFor()
			
			InputStream fis = pro.getInputStream();
            
			InputStreamReader isr = new InputStreamReader(fis, java.nio.charset.StandardCharsets.UTF_8);
            
			BufferedReader br = new BufferedReader(isr); 
			
            br.lines().forEach{line -> System.out.println(line)};
        }
        else
        {
            println "Obfuscation cannot be executed because publish location does not exist"
        }
    }
}

