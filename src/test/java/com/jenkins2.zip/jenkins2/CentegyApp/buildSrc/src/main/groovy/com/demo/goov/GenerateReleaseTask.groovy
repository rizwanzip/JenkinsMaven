package com.demo.goov

import org.gradle.api.DefaultTask
import org.gradle.api.file.Directory
import org.gradle.api.file.DirectoryProperty
import org.gradle.api.file.FileCollection
import org.gradle.api.provider.Property
import org.gradle.api.tasks.Input
import org.gradle.api.tasks.InputDirectory
import org.gradle.api.tasks.OutputDirectory
import org.gradle.api.tasks.PathSensitive
import org.gradle.api.tasks.PathSensitivity
import org.gradle.api.tasks.TaskAction
import org.gradle.api.tasks.incremental.IncrementalTaskInputs
import org.gradle.internal.file.FileType
import org.gradle.internal.impldep.org.apache.commons.io.FilenameUtils

import com.demo.goov.GroovUtils

import java.nio.charset.StandardCharsets
import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.Paths
import java.nio.file.StandardCopyOption
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.stream.Stream

class GenerateReleaseTask extends DefaultTask {
    @Input
    String forceFullRelease = false

    @InputDirectory
    def FileCollection sourceFiles

    @OutputDirectory
    def File publishDir

    def outputDir;
    def outputBinJenDir;
    def outputBinLibDir;

    @TaskAction
    void execute(IncrementalTaskInputs inputs) {
        boolean incrementalFilesfound = false;

        Date date = new Date();

        DateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmssSSS");
        String stringDate = sdf.format(date);

        println inputs.incremental ? "CHANGED inputs considered out of date" :
            "ALL inputs considered out of date"

        outputDir = GroovUtils.initDir(Paths.get(publishDir.path, project.version, "WEB-INF", "classes").toString());
        outputBinJenDir = GroovUtils.initDir(Paths.get(publishDir.path, "jen-libs").toString());
        outputBinLibDir = GroovUtils.initDir(Paths.get(publishDir.path, project.version, "WEB-INF", "lib").toString());

        File buildDiffFile = new File(java.nio.file.Paths.get(project.buildDir.path, project.name + "-" + project.version + ".txt").toString());

        if (inputs.incremental &&
            (!buildDiffFile.exists()) ||
            forceFullRelease.equals("true")) {
            println "Assembling changed input"

            inputs.outOfDate {
                change ->

                    incrementalFilesfound = true;

                if (change.file.isFile()) {
                    //println("Assembling file -> " + change.file.toPath() + ":" + outputDir.path);

                    try {
                        if (change.file.toPath().toString().contains("resources")) {
                            Path changeFilePath = Paths.get(outputDir.path, change.file.parentFile.path.substring(change.file.parentFile.path.indexOf("resources\\main") + 14))

                            project.copy {
                                from change.file
                                into "file://" + changeFilePath
                            }
                            println("Incremental Assembling static file -> " + change.file.toPath() + ":" + changeFilePath.toString());
                        } else {
                            Path changeFilePath = Paths.get(outputDir.path, change.file.parentFile.path.substring(change.file.parentFile.path.indexOf("java\\main") + 9))

                            project.copy {
                                from change.file
                                into "file://" + changeFilePath
                            }
                            println("Incremental Assembling java file -> " + change.file.toPath() + ":" + changeFilePath.toString());
                        }
                    } catch (Exception exp) {
                        println exp.message
                    }
                }
            }
        } else {

            println "buildDiffFile =======> " + buildDiffFile.toPath().toString()

            if (buildDiffFile.exists()) {
                Stream <String> stream = Files.lines(buildDiffFile.toPath(), StandardCharsets.UTF_8);

                stream.forEach {

                    incrementalFilesfound = true;

                    File change = new File(it);

                    String javaFileName = change.name.indexOf(".") > 0 ? change.name.substring(0, change.name.indexOf(".")) : change.name;
                    String pckName = change.parent

                    if (change.isFile()) {
                        //println("Assembling file (not incremental) -> " + change.toPath() + ":" + outputDir.path);

                        try {
                            if (change.toPath().toString().contains("resources")) {
                                Path changeFilePath = Paths.get(outputDir.path, change.parentFile.path.substring(change.parentFile.path.indexOf("resources\\main") + 14))

                                project.copy {
                                    from change
                                    into "file://" + changeFilePath
                                }

                                println("Not Incremental Assembling static file (not incremental) -> " + change.toPath() + ":" + outputDir.path);

                            } else {
                                Path changeFilePath = Paths.get(outputDir.path, change.parentFile.path.substring(change.parentFile.path.indexOf("java\\main") + 9))

                                project.copy {
                                    from change
                                    into "file://" + changeFilePath
                                }
                                println("Not Incremental Assembling java static file (not incremental) -> " + change.toPath() + ":" + outputDir.path);

                            }

                            if (!change.name.contains("\$")) {
                                project.fileTree("${pckName}").matching {
                                    include "**/${javaFileName}\$*"
                                }.each {
                                    File dollarchangefile = it
					println("Assembling dollor file ${dollarchangefile.toPath()}")
                                    project.copy {
                                        from dollarchangefile
                                        into "file://" + Paths.get(outputDir.path, dollarchangefile.parentFile.path.substring(dollarchangefile.parentFile.path.indexOf("java\\main") + 9))
                                    }
                                }
                            }
                        } catch (Exception exp) {
                            println exp.message
                        }
                    }
                };
            }
        }

        //        project.childProjects.each { p ->

        //        }

	updateSource();
        updateTPLs(incrementalFilesfound);

        cleanDir(incrementalFilesfound);
    }

	def updateSource() {
		try {
			String source = project.buildDir.parent.toString().concat("\\src");
			File srcDir = new File(source);

			String moduleName = project.buildDir.parent.toString().substring(project.buildDir.parent.toString().lastIndexOf('\\')+1)
			String branchName = project.version.substring(0,project.version.indexOf(".",project.version.indexOf(".")+1));

			String destination = "C:\\JenkinsHome\\template\\web\\source\\${branchName}\\CentegyApp\\${moduleName}\\src";
			File destDir = new File(destination);

			GroovUtils.initDir(destination)

			//FileUtils.copyDirectory(srcDir, destDir)
			project.copy {
				from srcDir
				into destDir
			}

			println("Srouce Copyied from ${srcDir.path} to ${destDir.path}")
			
		} catch (Exception e) {
			println("Srouce copying Error")
			e.printStackTrace()
		}
	}

    def updateTPLs(boolean incrementalFilesfound) {
        try {
            if (incrementalFilesfound) {
                project.configurations.runtime.each {


                    String jarFileName = it.name.lastIndexOf(".") > 0 ? it.name.substring(0, it.name.lastIndexOf(".")) : it.name;
                    String jarFileNameWithExt = it.name.lastIndexOf("\\") > 0 ? it.name.substring(0, it.name.lastIndexOf("\\")) : it.name;

                    if (!it.toString().contains("build") && !it.toString().contains("tomcat-embed") && !it.toString().contains("validation-api")) {
                        if (project.fileTree(outputBinJenDir).matching {
                                include "**/${jarFileName}*"
                            }.empty || forceFullRelease.equals("true")) {

                            println("copying new dependency ... $it --> $outputBinLibDir.path.${jarFileNameWithExt}, $outputBinJenDir.path.${jarFileNameWithExt}")

                            try {
                                Files.copy(Paths.get(it.toString()), Paths.get(outputBinLibDir.path, jarFileNameWithExt), StandardCopyOption.REPLACE_EXISTING);
                            } catch (Exception exp) {
                                println exp.message
                            }

                            try {
                                Files.copy(Paths.get(it.toString()), Paths.get(outputBinJenDir.path, jarFileNameWithExt), StandardCopyOption.REPLACE_EXISTING);
                            } catch (Exception exp) {
                                println exp.message
                            }
                        }
                    } else {

                        println("excluded new dependency ... $it")
                    }
                }
            }
        } catch (Exception exp) {
            println "-->" + exp.message
        }
    }

    def cleanDir(boolean incrementalFilesfound) {
        if (!incrementalFilesfound) {
            if (outputDir.exists())
                outputDir.delete();
        }
    }

    Optional <String> getExtensionByStringHandling(String filename) {
        return Optional.ofNullable(filename).filter {
            f -> f.contains(".")
        }.map {
            f -> f.substring(filename.lastIndexOf("."))
        };
    }
}