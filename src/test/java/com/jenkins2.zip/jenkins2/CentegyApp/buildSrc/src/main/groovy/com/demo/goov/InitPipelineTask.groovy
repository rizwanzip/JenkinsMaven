package com.demo.goov

import org.apache.tools.ant.Project
import org.gradle.api.DefaultTask
import org.gradle.api.tasks.TaskAction
import org.gradle.api.tasks.Input

import java.nio.file.Paths
import java.nio.file.Files
import java.util.Arrays


class InitPipelineTask extends DefaultTask {

    @Input
    String usePrevHist;

    @TaskAction
    void execute() {
        try {

            File buildDir = new File("${project.buildDir.path}");

            if (!buildDir.exists())
                buildDir.mkdirs();

            File buildDiffFile = new File(java.nio.file.Paths.get("${project.buildDir.path}", "${project.name}-" + project.version + ".txt").toString());

            println buildDiffFile.toPath().toString()

            if (usePrevHist == "false") {
                println "Pre build - calculating incremental build ==> " + project.version

                StringBuilder contentBuilder = new StringBuilder();

                project.fileTree("src").matching {
                    include "main/java/**/*.java"
                    include "main/resources/**"
                    exclude "**/package-info.java"
                }.each {
                    if (it.isFile()) {
						boolean filesAreEqual = false
						
						String javaFileName = it.name.indexOf(".") > 0 ? it.name.substring(0, it.name.indexOf(".")) : it.name;

						String pckName = ""
						if(it.toString().contains("resources")) {
										pckName = "${project.buildDir}\\".concat("resources\\main\\").concat(it.toString().substring(it.toString().indexOf("src\\main\\resources\\") + 19))
						} else {
										pckName = "${project.buildDir}\\".concat("classes\\java\\main\\").concat(it.toString().substring(it.toString().indexOf("src\\main\\java\\") + 14))				
						}

						pckName = new File(pckName).parent
						File srcFile = it;
						String branchName = project.version.substring(0,project.version.indexOf(".",project.version.indexOf(".")+1));

						try {
							File trgFile = new File("C:\\JenkinsHome\\template\\web\\source\\${branchName}\\CentegyApp" + srcFile.toPath().toString().substring(srcFile.toPath().toString().indexOf("CentegyApp")+10))
							byte[] srcFileBytes = Files.readAllBytes(it.toPath());
							byte[] trgFileBytes = Files.readAllBytes(trgFile.toPath());

							filesAreEqual = Arrays.equals(srcFileBytes, trgFileBytes);

							//println("file are equal -> ${filesAreEqual} - ${srcFile.toPath()}")
						} catch(Exception e) {
							//e.printStackTrace();
						}

						project.fileTree("${pckName}").matching {
							include "**/${javaFileName}*"
						}.each {
							if (srcFile.lastModified() > it.lastModified() && !filesAreEqual) {

								println String.format("%s %s --> %s || %s", javaFileName, srcFile.toPath().toString(), it.toPath().toString(), srcFile.lastModified().toString());

								contentBuilder.append("${it.toPath().toString()}").append("\n");
							}
						}

						if (project.fileTree("${project.buildDir}").matching {
								include "**/${javaFileName}*"
							}.empty) {
								if(!filesAreEqual) {
									println "Collecting new files " + it.toPath().toString();

									String itFileName = it.toPath().toString();
									if (itFileName.contains("resources"))
										itFileName = itFileName.replace("src\\main\\resources", "build\\resources\\main")
									else
										itFileName = itFileName.replace("src\\main\\java", "build\\classes\\java\\main").replace(".java", ".class")

									contentBuilder.append("${itFileName}").append("\n");
							}
						}
                    }
                }

                if (buildDiffFile.exists())
                    buildDiffFile.delete();

                try {
                    buildDiffFile.append(contentBuilder.toString());
                } catch (Exception e) {
                    e.printStackTrace()
                } finally {
                    buildDiffFile = null;
                }
            } else {
                if (!buildDiffFile.exists()) {
                    throw new Exception("History not found for this version, provide any existing version to generate release from build history");
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace()
        }
    }
}