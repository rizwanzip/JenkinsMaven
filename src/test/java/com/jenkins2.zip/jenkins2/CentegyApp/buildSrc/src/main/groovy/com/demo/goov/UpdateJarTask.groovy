package com.demo.goov

import org.gradle.api.DefaultTask
import org.gradle.api.file.Directory
import org.gradle.api.file.DirectoryProperty
import org.gradle.api.file.FileCollection
import org.gradle.api.provider.Property
import org.gradle.api.tasks.Input
import org.gradle.api.tasks.InputDirectory
import org.gradle.api.tasks.OutputDirectory
import org.gradle.api.tasks.PathSensitive
import org.gradle.api.tasks.PathSensitivity
import org.gradle.api.tasks.TaskAction
import org.gradle.api.tasks.incremental.IncrementalTaskInputs
import org.gradle.internal.file.FileType
import org.gradle.internal.impldep.org.apache.commons.io.FilenameUtils
import org.w3c.dom.NodeList

import javax.management.Attribute
import javax.xml.bind.JAXBContext
import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.Paths
import java.nio.file.StandardCopyOption

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.Element;

import javax.xml.transform.Transformer;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.OutputKeys;

class UpdateJarTask extends DefaultTask {

//    @Input
//    def File deploymentDir

    @Input
    def File publishDir
	
	def outputDir;

    @TaskAction
    void execute() {
		outputDir = GroovUtils.initFile(Paths.get(publishDir.path, project.version).toString());

        if (outputDir.exists()) {
            File targetDir = new File(Paths.get("$publishDir", "$project.version").toString());

            if (targetDir.exists()) {
                updateJar();

                //cleanAndCopyObfuscateInput();

                //modifyObfusConfig();
            }
        }
    }

    void updateJar() {
//        ant.jar(update: "true", destfile: "$deploymentDir/${project.name}.jar") {
//            fileset(dir: "$publishDir/$project.version/$project.name", includes: '/**')
//        }

        ant.jar(destfile: "$publishDir/jars/${project.version}.jar", baseDir: "$publishDir/$project.version")

//        task toJar (type: Jar) {
//            from sourceSets.all
//        }
    }

//    void cleanAndCopyObfuscateInput() {
//
//        project.file("$project.parent.projectDir/obfus/input/${project.name}.jar").delete()
//
//        project.copy {
//            from project.file("$deploymentDir/${project.name}.jar")
//            into project.file("$project.parent.projectDir/obfus/input")
//        }
//
//        cleanObfuscateConfigJarTag(Paths.get("$project.parent.projectDir", "obfus", "config.xml").toString());
//    }
//
//    void modifyObfusConfig() {
//        File inputFile = new File(Paths.get("$project.parent.projectDir", "obfus", "config.xml").toString());
//
//        DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
//        DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
//        Document doc = docBuilder.parse(inputFile);
//        Node jars = doc.getDocumentElement().getFirstChild().getNextSibling();
//
//
//        Element newJarNode = doc.createElement("${project.name}.jar");
//        newJarNode.setAttribute("in", "$deploymentDir/${project.name}.jar");
//        newJarNode.setAttribute("out", "$deploymentDir/${project.name}.jar");
//
//        jars.appendChild(newJarNode);
//
//        transformObfusConfig(doc);
//    }
//
//    void transformObfusConfig(Document document) {
//        Transformer transformer = TransformerFactory.newInstance().newTransformer();
//        transformer.setOutputProperty(OutputKeys.INDENT, "yes");
//        transformer.setOutputProperty(OutputKeys.METHOD, "xml");
//        transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "5");
//        DOMSource source = new DOMSource(document);
//        StreamResult result = new StreamResult(new File(Paths.get("$project.parent.projectDir", "obfus", "config.xml").toString()));
//        transformer.transform(source, result);
//    }
//
//    void removeAll(Node node, short nodeType, String name) {
//        if (node.getNodeType() == nodeType && (name == null || node.getNodeName().equals(name))) {
//            node.getParentNode().removeChild(node);
//        } else {
//            NodeList list = node.getChildNodes();
//            for (int i = 0; i < list.getLength(); i++) {
//                removeAll(list.item(i), nodeType, name);
//            }
//        }
//    }
//
//    void cleanObfuscateConfigJarTag(String configPath) {
//        File inputFile = new File(configPath);
//
//        DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
//        DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
//        Document doc = docBuilder.parse(inputFile);
//
//        removeAll(doc, Node.ELEMENT_NODE, "jar");
//    }
}
