package com.demo.goov

import org.gradle.api.DefaultTask
import org.gradle.api.file.Directory
import org.gradle.api.file.DirectoryProperty
import org.gradle.api.file.FileCollection
import org.gradle.api.provider.Property
import org.gradle.api.tasks.Input
import org.gradle.api.tasks.InputDirectory
import org.gradle.api.tasks.OutputDirectory
import org.gradle.api.tasks.PathSensitive
import org.gradle.api.tasks.PathSensitivity
import org.gradle.api.tasks.TaskAction
import org.gradle.api.tasks.incremental.IncrementalTaskInputs
import org.gradle.internal.file.FileType
import org.gradle.internal.impldep.org.apache.commons.io.FilenameUtils
import org.w3c.dom.NodeList

import javax.management.Attribute
import javax.xml.bind.JAXBContext
import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.Paths
import java.nio.file.StandardCopyOption

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.Element;

import javax.xml.transform.Transformer;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.OutputKeys;

import java.text.DateFormat;
import java.text.SimpleDateFormat;

class PrepareObfusInput extends DefaultTask {

    @Input
    def String logFileName

    @Input
    def File publishDir

    @Input
    def File obfusDir

    @TaskAction
    void execute() {
        println "$publishDir || $obfusDir"

        backupObfusPrevLog();
        backupObfusCurrLog();
        cleanObfuscateInput();
    }

    void backupObfusPrevLog() {
        Date date = new Date();
        DateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmssSSS");
        String stringDate = sdf.format(date);

        String orgLogFileName = "$obfusDir/logs/${logFileName}.xml";
        String fullLogFileName = "$obfusDir/logs history/${logFileName}.xml";
        String destFileName = "$obfusDir/logs history/${logFileName}-${stringDate}.xml";

        println "$obfusDir/logs history/${logFileName}-${stringDate}.xml"

        File orgLogfile = new File(orgLogFileName);
        File logfile = new File(fullLogFileName);

        File destfile = new File(destFileName);

        if (orgLogfile.exists()) {
            println "Backing previous log"
            println destfile.toPath().toString();

            logfile.renameTo(destfile)
        }
    }

    void backupObfusCurrLog() {
        String fullLogFileName = "$obfusDir/logs/${logFileName}.xml";
        String destFileName = "$obfusDir/logs history/${logFileName}.xml";

        println "Creating current log"

        File logfile = new File(fullLogFileName );
        File destfile = new File(destFileName);

        println destfile.toPath().toString();

        logfile.renameTo(destfile)
    }

    void cleanObfuscateInput() {

        //project.file("$project.parent.projectDir/obfus/input/${project.name}.jar").delete()
        //project.file("${obfusDir}/input/${project.name}.jar").delete()

        project.delete project.fileTree("${obfusDir}/input") {
            include "**/*.jar"
        }

        project.delete project.fileTree("${obfusDir}/output") {
            include "**/*.jar"
        }

        updateObfusConfig(Paths.get("${obfusDir}", "config.xml").toString());
    }

    void removeAll(Node node, short nodeType, String name, String parentName) {
        if (node.getNodeType() == nodeType && (name == null || node.getNodeName().equals(name))) {
            if(node.parentNode.getNodeName().equals(parentName)) {
                node.getParentNode().removeChild(node);
            }
        } else {
            NodeList list = node.getChildNodes();
            for (int i = 0; i < list.getLength(); i++) {
                removeAll(list.item(i), nodeType, name, "jars");
            }
        }
    }

    void updateObfusConfig(String configPath) {
        File inputFile = new File(configPath);

        DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
        Document doc = docBuilder.parse(inputFile);

        removeAll(doc, Node.ELEMENT_NODE, "jar", "jars");
        transformObfusConfig(doc);
    }
    void transformObfusConfig(Document document) {
        Transformer transformer = TransformerFactory.newInstance().newTransformer();
        transformer.setOutputProperty(OutputKeys.INDENT, "yes");
        transformer.setOutputProperty(OutputKeys.METHOD, "xml");
        transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "5");
        DOMSource source = new DOMSource(document);
        StreamResult result = new StreamResult(new File(Paths.get("$obfusDir", "config.xml").toString()));
        transformer.transform(source, result);
    }
}
