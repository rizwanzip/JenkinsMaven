package com.demo.goov

import org.gradle.api.DefaultTask
import org.gradle.api.file.Directory
import org.gradle.api.file.DirectoryProperty
import org.gradle.api.file.FileCollection
import org.gradle.api.provider.Property
import org.gradle.api.tasks.Input
import org.gradle.api.tasks.InputDirectory
import org.gradle.api.tasks.OutputDirectory
import org.gradle.api.tasks.PathSensitive
import org.gradle.api.tasks.PathSensitivity
import org.gradle.api.tasks.TaskAction
import org.gradle.api.tasks.incremental.IncrementalTaskInputs
import org.gradle.internal.file.FileType
import org.gradle.internal.impldep.org.apache.commons.io.FilenameUtils

import java.nio.charset.StandardCharsets
import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.Paths
import java.nio.file.StandardCopyOption
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.stream.Stream

class GenerateReleaseTask extends DefaultTask {
    @InputDirectory
    def FileCollection sourceFiles

    @OutputDirectory
    def File publishDir
//
//    @Input
//    String[] libs = []

    @TaskAction
    void execute(IncrementalTaskInputs inputs) {
        boolean incrementalFilesfound = false;

        Date date = new Date();

        DateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmssSSS");
        String stringDate = sdf.format(date);
        
        println inputs.incremental ? "CHANGED inputs considered out of date"
                : "ALL inputs considered out of date"

        String outputrep = Paths.get(publishDir.path, project.version);

        File outputDir = new File(outputrep);

        if (outputDir.exists()) {
            outputDir.delete();
            outputDir.mkdir();
        }
        else {
            outputDir.mkdir();
        }

        if(inputs.incremental)
        {
            inputs.outOfDate { change ->

                incrementalFilesfound = true;

                if (change.file.isFile()) {
                    println("Assembling file -> " + change.file.toPath() + ":" + outputDir.path);

                    project.copy {
                        from change.file
                        into "file://" + Paths.get(outputrep, project.name, change.file.parentFile.path.substring(change.file.parentFile.path.indexOf("\\main") + 5))
                    }
                }
            }
        }
        else {
            File buildDiffFile = new File(java.nio.file.Paths.get(project.buildDir.path, project.name + "-" + project.version + ".txt").toString());

            println "buildDiffFile =======> " + buildDiffFile.toPath().toString()

            if (buildDiffFile.exists()) {
                Stream<String> stream = Files.lines(buildDiffFile.toPath(), StandardCharsets.UTF_8);

                stream.forEach {

                    incrementalFilesfound = true;

                    File change = new File(it);

                    if (change.isFile()) {
                        println("Assembling file (not incremental) -> " + change.toPath() + ":" + outputDir.path);

                        project.copy {
                            from change
                            into "file://" + Paths.get(outputrep, project.name, change.parentFile.path.substring(change.parentFile.path.indexOf("\\main") + 5))
                        }
                    }
                };
            }
        }

        if(!incrementalFilesfound)
            if (outputDir.exists())
                outputDir.delete();

//        libs.each { l ->
//            project.sync {
//                from project.childProjects[l].configurations.getByName("runtime")
//                into outputrep + "/WEB-INF/lib"
//            }
//        }
    }

    Optional<String> getExtensionByStringHandling(String filename) {
        return Optional.ofNullable(filename).filter { f -> f.contains(".") }.map { f -> f.substring(filename.lastIndexOf(".")) };
    }
}
