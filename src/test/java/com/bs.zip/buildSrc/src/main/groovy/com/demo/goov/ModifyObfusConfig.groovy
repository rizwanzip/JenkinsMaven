package com.demo.goov

import org.gradle.api.DefaultTask
import org.gradle.api.file.Directory
import org.gradle.api.file.DirectoryProperty
import org.gradle.api.file.FileCollection
import org.gradle.api.provider.Property
import org.gradle.api.tasks.Input
import org.gradle.api.tasks.InputDirectory
import org.gradle.api.tasks.OutputDirectory
import org.gradle.api.tasks.PathSensitive
import org.gradle.api.tasks.PathSensitivity
import org.gradle.api.tasks.TaskAction
import org.gradle.api.tasks.incremental.IncrementalTaskInputs
import org.gradle.internal.file.FileType
import org.gradle.internal.impldep.org.apache.commons.io.FilenameUtils
import org.w3c.dom.NodeList

import javax.management.Attribute
import javax.xml.bind.JAXBContext
import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.Paths
import java.nio.file.StandardCopyOption

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.Element;

import javax.xml.transform.Transformer;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.OutputKeys;

class ModifyObfusConfig extends DefaultTask {

//    @Input
//    def File deploymentDir

    @Input
    def File publishDir

    @Input
    def File obfusDir

    @TaskAction
    void execute() {
        String outputrep = Paths.get(publishDir.path, project.version);

        File outputDir = new File(outputrep);

        if (outputDir.exists()) {
            File targetDir = new File(Paths.get("$publishDir", "$project.version", "$project.name").toString());

            if (targetDir.exists()) {
                modifyObfuscateConfig();
            }
        }
        else
        {
            println "Obfuscation cannot be cofigured because publish location does not exist"
        }
    }

    void modifyObfuscateConfig() {

        project.copy {
            from project.file("$publishDir/$project.version/jars/${project.name}.jar")
            //into project.file("$project.parent.projectDir/obfus/input")
            into project.file("${obfusDir}/input")
        }

        //updateObfusConfig(Paths.get("$project.parent.projectDir", "obfus", "config.xml").toString());
        updateObfusConfig(Paths.get("${obfusDir}", "config.xml").toString());
    }

    void updateObfusConfig(String configPath) {
        File inputFile = new File(Paths.get("$project.parent.projectDir", "obfus", "config.xml").toString());

        DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
        Document doc = docBuilder.parse(inputFile);
        Node jars = doc.getDocumentElement().getFirstChild().getNextSibling();

        Element newJarNode = doc.createElement("jar");
        newJarNode.setAttribute("in", "$obfusDir/input/${project.name}.jar");
        newJarNode.setAttribute("out", "$obfusDir/output/${project.name}-obfus.jar");

        jars.appendChild(newJarNode);

        transformObfusConfig(doc);
    }

    void transformObfusConfig(Document document) {
        Transformer transformer = TransformerFactory.newInstance().newTransformer();
        transformer.setOutputProperty(OutputKeys.INDENT, "yes");
        transformer.setOutputProperty(OutputKeys.METHOD, "xml");
        transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "5");
        DOMSource source = new DOMSource(document);
        StreamResult result = new StreamResult(new File(Paths.get("$project.parent.projectDir", "obfus", "config.xml").toString()));
        transformer.transform(source, result);
    }

}
