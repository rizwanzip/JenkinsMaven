package com.demo.goov

import org.gradle.api.DefaultTask
import org.gradle.api.tasks.TaskAction

class InitPipelineTask extends DefaultTask {

    @TaskAction
    void execute() {
        println "Pre build - calculating incremental build ==> " + project.version

        StringBuilder contentBuilder = new StringBuilder();

        File buildDiffFile = new File(java.nio.file.Paths.get("${project.buildDir.path}", "${project.name}-" + project.version + ".txt").toString());

        println buildDiffFile.toPath().toString()

        project.fileTree("src").matching {
            include "**/*.java"
        }.each {
            String javaFileName = it.name.substring(0, it.name.indexOf("."));

            File javaFile = it;

            project.fileTree("${project.buildDir}").matching {
                include "**/${javaFileName}*.class"
            }.each {
                // do some operations
                if (javaFile.lastModified() > it.lastModified()) {

                    println it.toPath().toString();

                    contentBuilder.append("${it.toPath().toString()}").append("\n");
                }
            }
        }

        if (buildDiffFile.exists())
            buildDiffFile.delete();

        buildDiffFile.append(contentBuilder.toString());
    }
}

