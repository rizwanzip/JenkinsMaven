package com.demo.goov

import org.gradle.api.DefaultTask
import org.gradle.api.tasks.TaskAction
import org.gradle.api.tasks.Input

import java.nio.file.Paths

class RunObfusTask extends DefaultTask {

    @Input
    def File publishDir

    @TaskAction
    void execute() {
        String outputrep = Paths.get(publishDir.path, project.version);

        File outputDir = new File(outputrep);

        if (outputDir.exists()) {
            Runtime.getRuntime().exec("obfus\\RunAllatori.bat")
        }
        else
        {
            println "Obfuscation cannot be executed because publish location does not exist"
        }
    }
}

